%% Solves qs 3.10 for assignment 2

% Solve and compare the least square problem
function GramSchmidt()
end